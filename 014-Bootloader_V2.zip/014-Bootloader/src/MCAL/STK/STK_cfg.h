/*
 * STK_cfg.h
 *
 *  Created on: Sep 1, 2022
 *      Author: mazen
 */

#ifndef MCAL_STK_STK_CFG_H_
#define MCAL_STK_STK_CFG_H_


#define STK_CLK_SOURCE     STK_AHB_DIV_8
#define STK_INTERRPUT_EN   DISABLE

#endif /* MCAL_STK_STK_CFG_H_ */
