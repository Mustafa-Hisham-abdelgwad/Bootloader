/*
 * DMA_cfg.h
 *
 *  Created on: Oct 11, 2022
 *      Author: mazen
 */

#ifndef MCAL_DMA_DMA_CFG_H_
#define MCAL_DMA_DMA_CFG_H_





#endif /* MCAL_DMA_DMA_CFG_H_ */
