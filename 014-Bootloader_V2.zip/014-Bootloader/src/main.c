
#include "LIB/STD_TYPES.h"
#include "MCAL/RCC/RCC_int.h"
//#include "MCAL/FMI/FMI_int.h"
#include "MCAL/GPIO/GPIO_int.h"
#include "MCAL/UART/UART_int.h"
#include "MCAL/STK/STK_int.h"
#include "APP/HexParser/HexParser_int.h"


u8 G_pu8RxBuffer[50] ;
u8 G_u8RxBufferCounter = 0;


typedef void (*function_t)(void);

function_t App_Call;

u8 TimeoutFlag = 0 ;
u8 EraseFlag = 0 ;

u8  MUART_vReceive_synch(u8* A_pu8Byte)
{
	u8 L_u8status = 1 ;
	if( GET_BIT(UART->SR, RX_FLAG) == 1 )
	{
		*A_pu8Byte = UART->DR ;
	}
	else
	{
		L_u8status = 0;
	}

	return L_u8status ;
}

void STK_Callback(void)
{
	TimeoutFlag = 1 ;

#define SCB_VTOR   *((volatile u32*)(0xE000ED00+0x08))

	SCB_VTOR = 0x08004000 ;

	App_Call = (function_t*) 0x08004004 ;

	App_Call();

}

int main(void)
{
	MRCC_vInit(); // HSI
	MRCC_vEnableClock(RCC_AHB1, RCC_EN_FMI);
	MRCC_vEnableClock(RCC_APB2, RCC_EN_UART);
	MRCC_vEnableclock(RCC_AHB1, RCC_EN_GPIOA);


MGPIO_Config_t uart_tx_pin = {
		.Port = GPIO_PORTA,
		.Pin  = GPIO_PIN9,
		.Mode = GPIO_MODE_ALTFUN,
		.OutputSpeed = GPIO_SPEED_MED,
		.OutputType = GPIO_OTYPE_PUSHPULL,
		.AltFunc    = 7
};

MGPIO_Config_t uart_rx_pin = {
		.Port = GPIO_PORTA,
		.Pin  = GPIO_PIN10,
		.Mode = GPIO_MODE_ALTFUN,
		.OutputSpeed = GPIO_SPEED_MED,
		.OutputType = GPIO_OTYPE_PUSHPULL,
		.AltFunc    = 7
};
	MGPIO_vInit(&uart_tx_pin);
	MGPIO_vInit(&uart_rx_pin);


	MUART_vInit(); // 9600, 1 stop bit , no parity , 8 bit data

	// enable STK interrupt
	MSTK_vInit(); // HSI/8 -> 2MHZ -> TickTime = 0.5 us

	MSTK_vSetInterval_single(15000000*2, STK_Callback);
	u8 L_u8UartRXStatus = 0;
	while(TimeoutFlag == 0)
	{
		L_u8UartRXStatus = MUART_vReceive_synch(&G_pu8RxBuffer[G_u8RxBufferCounter]) ;
		if(L_u8UartRXStatus == 1)
		{
			if(EraseFlag != 1)
			{
				EraseFlag = 1;
				HexParser_vEraseAppArea();
			}


			/* stop the timeout */
			MSTK_vStopInterval(); // CLR_BIT(STK->CTRL, EN); STK->VAL = 0;

			if(G_pu8RxBuffer[G_u8RxBufferCounter] == '\n')
			{

				HexParser_vParseData(G_pu8RxBuffer) ;
				MUART_vSendString("ok");
				G_u8RxBufferCounter = 0 ;
			}
			else
			{
				G_u8RxBufferCounter++ ;
			}

			// End of file
			if(G_pu8RxBuffer[8] == '1')
			{
				MSTK_vSetInterval_single(1000000,STK_Callback);
//				STK_Callback();
			}
		}
	}
}
